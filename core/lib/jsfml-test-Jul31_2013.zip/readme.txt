This is the JSFML test release as of July 31st, 2013.

The platforms supported are Windows, Linux and Mac OS X each 32 and 64 bit.
Java 7 is required.

Run jsfml-test.jar for a quick test of functionality.
On Mac OS X, you must run it using the "-XstartOnFirstThread" JVM argument.

http://jsfml.org/
